"""
Verizon Customer Management System
Author: Angie Lee
Date: 09/23/2024
Project2 Database File
"""

import sqlite3
import datetime

# All SQL queries
CREATE_CUSTOMERS_TABLE = """CREATE TABLE IF NOT EXISTS customers(
    customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT,
    customer_number INTEGER
);"""

CREATE_PAYMENTS_TABLE = """CREATE TABLE IF NOT EXISTS payments(
    payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    amount_due INTEGER,
    last_payment_date TEXT,
    payment_status INTEGER DEFAULT 0
);"""

CREATE_EQUIPMENTS_TABLE = """CREATE TABLE IF NOT EXISTS equipments(
    equipment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    location_id INTEGER,
    cost_of_equipment INTEGER,
    equipment_type TEXT
);"""

CREATE_SERVICES_TABLE = """CREATE TABLE IF NOT EXISTS services( 
    service_id INTEGER PRIMARY KEY AUTOINCREMENT,
    location_id INTEGER,
    service_type TEXT,
    cost_of_service INTEGER
);"""

CREATE_LOCATIONS_TABLE = """CREATE TABLE IF NOT EXISTS locations(
    location_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    address TEXT
);"""

INSERT_CUSTOMER = "INSERT INTO customers (customer_name, customer_number) VALUES (?, ?);"
INSERT_PAYMENT = "INSERT INTO payments (customer_id, last_payment_date, payment_status) VALUES (?, ?, ?);"
REMOVE_CUSTOMER = "DELETE FROM customers WHERE customer_name = ?;"
SELECT_ALL_CUSTOMERS = """
    SELECT customers.customer_name, locations.location_id, payments.payment_status,
           customers.customer_number, locations.address
    FROM customers
    LEFT JOIN locations ON customers.customer_id = locations.customer_id
    LEFT JOIN payments ON customers.customer_id = payments.customer_id;
"""
VIEW_LATE_CUSTOMERS = """
    SELECT customers.customer_name, payments.last_payment_date
    FROM customers
    JOIN payments ON customers.customer_id = payments.customer_id
    WHERE payments.payment_status = 1;
"""
UPDATE_PAYMENT = "UPDATE payments SET last_payment_date = ?, payment_status = ? WHERE customer_id = ?;"
LATEST_PAYMENT = """
    SELECT customer_name, last_payment_date 
    FROM customers 
    JOIN payments ON customers.customer_id = payments.customer_id 
    ORDER BY payments.last_payment_date DESC 
    LIMIT 1;
"""
INSERT_SERVICE = "INSERT INTO services (location_id, service_type, cost_of_service) VALUES (?, ?, ?);"
REMOVE_SERVICE = "DELETE FROM services WHERE location_id = ? AND service_type = ?;"
INSERT_EQUIPMENT = "INSERT INTO equipments (location_id, equipment_type, cost_of_equipment) VALUES (?, ?, ?);"
REMOVE_EQUIPMENT = "DELETE FROM equipments WHERE location_id = ? AND equipment_type = ?;"
UPDATE_SERVICE_COST = "UPDATE services SET cost_of_service = ? WHERE location_id = ? AND service_type = ?;"
UPDATE_EQUIPMENT_COST = "UPDATE equipments SET cost_of_equipment = ? WHERE location_id = ? AND equipment_type = ?;"
UPDATE_BILL_AMOUNT = """
    UPDATE payments
    SET amount_due = (
        SELECT COALESCE(SUM(
            COALESCE(s.cost_of_service, 0) + COALESCE(e.cost_of_equipment, 0)
        ), 0)
        FROM locations l
        LEFT JOIN services s ON l.location_id = s.location_id
        LEFT JOIN equipments e ON l.location_id = e.location_id
        WHERE l.customer_id = ?
    )
    WHERE customer_id = ?;
"""
SEARCH_CUSTOMERS = """
    SELECT DISTINCT customers.customer_id, customers.customer_name, customers.customer_number, locations.address
    FROM customers 
    LEFT JOIN locations ON customers.customer_id = locations.customer_id
    WHERE customers.customer_name LIKE ? 
    OR locations.address LIKE ?
    OR customers.customer_number LIKE ?;
"""
GET_AMOUNT_DUE = "SELECT amount_due FROM payments WHERE customer_id = ?;"
INSERT_LOCATION = "INSERT INTO locations (customer_id, address) VALUES (?, ?);"
GET_LOCATION = "SELECT location_id FROM locations WHERE customer_id = ?;"

# Database connection
connection = sqlite3.connect("customers.db")


def create_tables():
    """
    Create all necessary tables in the database if they don't already exist.
    """
    with connection:
        connection.execute(CREATE_CUSTOMERS_TABLE)
        connection.execute(CREATE_PAYMENTS_TABLE)
        connection.execute(CREATE_EQUIPMENTS_TABLE)
        connection.execute(CREATE_SERVICES_TABLE)
        connection.execute(CREATE_LOCATIONS_TABLE)

def is_payment_late(last_payment_date):
    """
    Check if a payment is late based on the last payment date.

    Args:
    last_payment_date (str): The date of the last payment in format "mm/dd/yyyy"

    Returns:
    int: 1 if the payment is late, 0 otherwise
    """
    thirty_days = datetime.timedelta(days=30).total_seconds()
    today = datetime.datetime.today().timestamp()
    last_payment = datetime.datetime.strptime(last_payment_date, "%m/%d/%Y").timestamp()
    return 1 if today - last_payment >= thirty_days else 0

def insert_customer(customer_name, customer_number, last_payment_date):
    """
    Insert a new customer into the database along with their initial payment information.

    Args:
    customer_name (str): The name of the customer
    customer_number (int): The customer's phone number
    last_payment_date (str): The date of the last payment in format "mm/dd/yyyy"

    Returns:
    int: The ID of the newly inserted customer, or None if an error occurred
    """
    try:
        with connection:
            cursor = connection.cursor()
            cursor.execute(INSERT_CUSTOMER, (customer_name, customer_number))
            customer_id = cursor.lastrowid

            payment_status = is_payment_late(last_payment_date)
            cursor.execute(INSERT_PAYMENT, (customer_id, last_payment_date, payment_status))

        return customer_id
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
        return None
def remove_customer(customer_name):
    """
    Remove a customer from the database based on their name.

    Args:
    customer_name (str): The name of the customer to be removed
    """
    with connection:
        connection.execute(REMOVE_CUSTOMER, (customer_name,))


def view_all_customers():
    """
    Retrieve a list of all customers with their details from the database.

    Returns:
    list: A list of tuples containing customer details
          (name, location_id, payment_status, phone_number, address)
    """
    cursor = connection.cursor()
    cursor.execute(SELECT_ALL_CUSTOMERS)
    customers = cursor.fetchall()
    return customers

def view_late_customers():
    """
    Retrieve a list of customers with late payments.

    Returns:
    list: A list of tuples containing customer names and their last payment dates
    """
    cursor = connection.cursor()
    cursor.execute(VIEW_LATE_CUSTOMERS)
    return cursor.fetchall()

def update_payment_made(customer_id, last_payment_date):
    """
    Update the payment information for a customer.

    Args:
    customer_id (int): The ID of the customer
    last_payment_date (str): The date of the last payment in format "mm/dd/yyyy"
    """
    payment_status = is_payment_late(last_payment_date)
    with connection:
        connection.execute(UPDATE_PAYMENT, (last_payment_date, payment_status, customer_id))

def latest_payment_made():
    """
    Retrieve the most recent payment made by any customer.

    Returns:
    tuple: A tuple containing the customer name and the date of their latest payment
    """
    cursor = connection.cursor()
    cursor.execute(LATEST_PAYMENT)
    return cursor.fetchone()

def add_service(location_id, service_type, cost_of_service):
    """
    Add a new service for a specific location.

    Args:
    location_id (int): The ID of the location
    service_type (str): The type of service being added
    cost_of_service (float): The cost of the service
    """
    with connection:
        connection.execute(INSERT_SERVICE, (location_id, service_type, cost_of_service))

def remove_service(location_id, service_type):
    """
    Remove a service from a specific location.

    Args:
    location_id (int): The ID of the location
    service_type (str): The type of service being removed
    """
    with connection:
        connection.execute(REMOVE_SERVICE, (location_id, service_type))

def add_equipment(location_id, equipment_type, cost_of_equipment):
    """
    Add new equipment for a specific location.

    Args:
    location_id (int): The ID of the location
    equipment_type (str): The type of equipment being added
    cost_of_equipment (float): The cost of the equipment
    """
    with connection:
        connection.execute(INSERT_EQUIPMENT, (location_id, equipment_type, cost_of_equipment))

def remove_equipment(location_id, equipment_type):
    """
    Remove equipment from a specific location.

    Args:
    location_id (int): The ID of the location
    equipment_type (str): The type of equipment being removed
    """
    with connection:
        connection.execute(REMOVE_EQUIPMENT, (location_id, equipment_type))

def update_service_cost(location_id, service_type, new_cost):
    """
    Update the cost of a service for a specific location.

    Args:
    location_id (int): The ID of the location
    service_type (str): The type of service being updated
    new_cost (float): The new cost of the service
    """
    with connection:
        connection.execute(UPDATE_SERVICE_COST, (new_cost, location_id, service_type))

def update_equipment_cost(location_id, equipment_type, new_cost):
    """
    Update the cost of equipment for a specific location.

    Args:
    location_id (int): The ID of the location
    equipment_type (str): The type of equipment being updated
    new_cost (float): The new cost of the equipment
    """
    with connection:
        connection.execute(UPDATE_EQUIPMENT_COST, (new_cost, location_id, equipment_type))

def update_bill_amount(customer_id, new_amount):
    """
    Update the total bill amount for a customer.

    Args:
    customer_id (int): The ID of the customer
    new_amount (float): The new bill amount

    Returns:
    bool: True if the update was successful, False otherwise
    """
    try:
        with connection:
            connection.execute(UPDATE_BILL_AMOUNT, (new_amount, customer_id))
        return True
    except sqlite3.Error as e:
        print(f"An error occurred while updating bill amount: {e}")
        return False

def search_customers(search_term):
    """
    Search for customers based on a search term.

    Args:
    search_term (str): The term to search for in customer names, addresses, or phone numbers

    Returns:
    list: A list of tuples containing matching customer information
    """
    cursor = connection.cursor()
    search_param = f'%{search_term}%'
    cursor.execute(SEARCH_CUSTOMERS, (search_param, search_param, search_param))
    return cursor.fetchall()

def get_amount_due(customer_id):
    """
    Get the amount due for a specific customer.

    Args:
    customer_id (int): The ID of the customer

    Returns:
    float: The amount due for the customer, or None if an error occurred
    """
    try:
        with connection:
            cursor = connection.cursor()
            cursor.execute(GET_AMOUNT_DUE, (customer_id,))
            result = cursor.fetchone()
            return result[0] if result else None
    except sqlite3.Error as e:
        print(f"An error occurred while fetching amount due: {e}")
        return None


def insert_location(customer_id, address):
    """
    Insert a new location for a customer.
    Args:
    customer_id (int): The ID of the customer
    address (str): The address of the location
    Returns:
    int: The ID of the newly inserted location
    Raises:
    sqlite3.Error: If there's a database error
    """
    try:
        with connection:
            cursor = connection.cursor()
            cursor.execute(INSERT_LOCATION, (customer_id, address))
            new_id = cursor.lastrowid
            if new_id is not None:
                return new_id
            else:
                raise ValueError("Failed to insert location: no ID was returned")
    except sqlite3.Error as e:
        print(f"An error occurred while inserting location: {e}")
        raise
def get_location(customer_id):
    """
    Get the location ID for a specific customer.
    Args:
    customer_id (int): The ID of the customer
    Returns:
    int: The location ID for the customer
    Raises:
    ValueError: If the location is not found

    """
    try:
        with connection:
            cursor = connection.cursor()
            cursor.execute(GET_LOCATION, (customer_id,))
            result = cursor.fetchone()
            if result:
                return result[0]
            else:
                raise ValueError(f"Location not found for customer ID: {customer_id}")
    except sqlite3.Error as e:
        print(f"An error occurred while fetching location: {e}")
        raise