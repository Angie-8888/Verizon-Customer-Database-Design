"""
Verizon Customer Management System
Author: Angie Lee
Date: 09/23/2024
Project2 Main File
"""

import database

MENU = '''
Please select one of the following options:
1. Insert new customers
2. Remove customers
3. Search customers by name or location
4. View all customers who are late on payment
5. Update last payment made
6. Add and remove services and equipment for a customer
7. Change cost of service or equipment
8. Change bill amount due each month for customer
9. View all customers
10. Exit
'''

def prompt_add_customer():
    """Prompt user to add a new customer and insert into the database."""
    customer_name = input("What is the customer's name? ").title()
    customer_number = input("What is the customer's number? ")
    last_payment_date = input("Enter the last payment date (MM/DD/YYYY): ")
    address = input("Enter the customer's address: ")

    customer_id = database.insert_customer(customer_name, customer_number, last_payment_date)
    if customer_id:
        location_id = database.insert_location(customer_id, address)
        if location_id:
            print(f"'{customer_name}' has been added to the database with ID {customer_id}, payment information, and location.")
        else:
            print(f"'{customer_name}' has been added, but there was an issue adding the location.")
    else:
        print("Failed to add customer.")


def prompt_remove_customer():
    """Prompt user to remove a customer from the database."""
    customer_name = input("Enter the name of the customer to be removed: ")
    database.remove_customer(customer_name)
    print(f"'{customer_name}' has been removed from the database.")

def prompt_search_customers():
    """Prompt user to search for customers and display results."""
    search_term = input("Enter name or location to search: ")
    results = database.search_customers(search_term)
    if results:
        for customer in results:
            print(f"ID: {customer[0]}, Name: {customer[1]}, Number: {customer[2]}, Address: {customer[3]}")
    else:
        print("No matching customers found.")


def prompt_view_all_customers():
    """Display details of all customers."""
    customers = database.view_all_customers()
    if customers:
        print("\nAll Customers:")
        print("Name | Location ID | Payment Status | Phone Number | Address")
        print("-" * 70)
        for customer in customers:

            if isinstance(customer, tuple) and len(customer) >= 5:
                name = customer[0] if customer[0] else "N/A"
                location_id = customer[1] if customer[1] else "N/A"
                payment_status = "Paid" if customer[2] == 0 else "Late"
                phone_number = customer[3] if customer[3] else "N/A"
                address = customer[4] if customer[4] else "N/A"

                print(f"{name} | {location_id} | {payment_status} | {phone_number} | {address}")
            else:
                print(customer)
    else:
        print("No customers found in the database.")
def prompt_late_customers():
    """Display all customers who are late on payment."""
    late_customers = database.view_late_customers()
    print("Customers who are late on payment:")
    if late_customers:
        for customer in late_customers:
            print(f"Name: {customer[0]}, Last Payment: {customer[1]}")
    else:
        print("No customers are currently late on payments.")

def prompt_update_payment():
    """Prompt user to update a customer's payment information."""
    customer_id = input("What is the customer's ID? ")
    last_payment_date = input("Enter the last payment date (MM/DD/YYYY): ")

    database.update_payment_made(customer_id, last_payment_date)
    print("Payment has been updated in the database.")


def prompt_add_or_remove_services_and_equipment():
    """Prompt user to add or remove services and equipment for a customer."""
    customer_id = input("Enter the customer ID: ")
    location_id = database.get_location(customer_id)
    if not location_id:
        print("No location found for this customer.")
        return

    item_type = input("Enter 'S' for service or 'E' for equipment: ").upper()

    if item_type == 'S':
        service_type = input("Enter the service type: ")
        cost = float(input("Enter the cost of service: "))
        database.add_service(location_id, service_type, cost)
    elif item_type == 'E':
        equipment_type = input("Enter the equipment type: ")
        cost = float(input("Enter the cost of equipment: "))
        database.add_equipment(location_id, equipment_type, cost)
    else:
        print("Invalid option selected.")

    database.update_bill_amount(customer_id)
    print(f"Bill amount updated for customer ID: {customer_id}")

def prompt_change_cost():
    """Prompt user to change the cost of a service or equipment."""
    location_id = input("Enter the customer's location ID: ")
    item_type = input("Enter 'S' for service or 'E' for equipment: ").upper()
    if item_type == 'S':
        service_type = input("Enter the service type: ")
        new_cost = float(input("Enter the new cost: "))
        database.update_service_cost(location_id, service_type, new_cost)
        print("Service cost updated.")
    elif item_type == 'E':
        equipment_type = input("Enter the equipment type: ")
        new_cost = float(input("Enter the new cost: "))
        database.update_equipment_cost(location_id, equipment_type, new_cost)
        print("Equipment cost updated.")
    else:
        print("Invalid option selected.")

def prompt_change_bill():
    """Prompt user to update a customer's bill amount."""
    customer_id = input("Enter the customer ID: ")

    # Get the current bill amount
    current_amount = database.get_amount_due(customer_id)
    if current_amount is not None:
        print(f"Current bill amount: ${current_amount:.2f}")
    else:
        print("Unable to retrieve current bill amount.")
        return

    # Prompt for new bill amount
    while True:
        try:
            new_amount = float(input("Enter the new bill amount: $"))
            if new_amount < 0:
                print("Bill amount cannot be negative. Please try again.")
            else:
                break
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    # Update the bill amount
    success = database.update_bill_amount(customer_id, new_amount)
    if success:
        print(f"Bill amount updated. New amount due: ${new_amount:.2f}")
    else:
        print("Failed to update bill amount.")
def prompt_view_all_customers():
    """Display details of all customers."""
    customers = database.view_all_customers()
    if customers:
        print("\nAll Customers:")
        print("Name | Location ID | Payment Status | Phone Number | Address")

        print("-" * 100)

        for customer in customers:
            name, location_id, payment_status, phone_number, address = customer
            payment_status_str = "Paid" if payment_status == 0 else "Late"
            print(f"{name} | {location_id or 'N/A'} | {payment_status_str} | {phone_number} | {address or 'N/A'}")
    else:
        print("No customers found in the database.")
def main():
    """Main function to run the Verizon Customer Management System."""
    print("Welcome to Verizon Customer Management System!")
    database.create_tables()

    while (user_input := input(MENU)) != "10":

        if user_input == "1":
            prompt_add_customer()
        elif user_input == "2":
            prompt_remove_customer()
        elif user_input == "3":
            prompt_search_customers()
        elif user_input == "4":
            prompt_late_customers()
        elif user_input == "5":
            prompt_update_payment()
        elif user_input == "6":
            prompt_add_or_remove_services_and_equipment()
        elif user_input == "7":
            prompt_change_cost()
        elif user_input == "8":
            prompt_change_bill()
        elif user_input == "9":
            prompt_view_all_customers()
        else:
            print("Invalid option. Please try again.")

    print("Thank you for using the Verizon Customer Management System. Goodbye!")

if __name__ == "__main__":
    main()